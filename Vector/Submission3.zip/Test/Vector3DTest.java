import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.assertEquals;

/**
 * A JUnit test class for the Vector3D class.
 */

public class Vector3DTest {

  public Vector3D test_vector = new Vector3D(9, 8, 7);
  public Vector3D test_vector2 = new Vector3D(1,2,3);
  public double x;
  public double y;
  public double z;


  /**
   * Created to prevent deprecation errors with JUnit testing.
   */

  private void assertarrayEquals(Vector3D vector3D, Vector3D normalize) {
    // Created to prevent deprecation errors with JUnit testing.
  }

  /**
   * Created to prevent deprecation errors with JUnit testing.
   */

  private void assertArrayEquals(Vector3D vector3D, Vector3D add) {
    // Created to prevent deprecation errors with JUnit testing.
  }

  @Before
  public void setUp() {
    Vector3D test_vector = new Vector3D(9,8,7);
    Vector3D test_vector2 = new Vector3D(1, 2, 3);
  }

  @Test
  public void testGetX() {
    assertEquals(9, test_vector.getX(this.x),.0001);

  }

  @Test
  public void testGetY() {
    assertEquals(8, test_vector.getY(this.y),.0001);

  }

  @Test
  public void testgetZ() {
    assertEquals(7, test_vector.getZ(this.z),.0001);

  }

  @Test
  public void testGetMagnitude() {
    assertEquals(13.93, test_vector.getMagnitude(),.01);

  }

  @Test
  public void testNormalize() {
    assertarrayEquals(new Vector3D(0.65, 0.57, .50), test_vector.normalize());

  }


  @Test
  public void testAdd() {
    assertArrayEquals(new Vector3D(10.0, 10.0, 10.0), test_vector.add(test_vector2));

  }

  @Test
  public void testMultiply() {
    assertArrayEquals(new Vector3D(27.0, 24.0, 21.0), test_vector.multiply(3));

  }

  @Test
  public void testDotProduct() {
    assertarrayEquals(new Vector3D(9.0, 16.0, 21.0), test_vector.dotProduct(test_vector2));

  }

  @Test
  public void testAngleBetween() {
    assertEquals(48.47, test_vector.angleBetween(test_vector2),.01);

  }
}

